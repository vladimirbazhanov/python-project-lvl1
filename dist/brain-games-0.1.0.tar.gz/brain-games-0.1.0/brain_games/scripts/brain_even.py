from brain_games.brain_even import start_game


def main():
    start_game()


if __name__ == '__main__':
    main()
