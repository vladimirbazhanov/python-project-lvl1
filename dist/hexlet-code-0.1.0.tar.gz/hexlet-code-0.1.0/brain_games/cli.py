import prompt


def welcome_user():
    print('Welcome to the Brain Games!')


def get_username():
    return prompt.string('May I have your name? ')
